# Campeonato de Menores 2025 - LFCH
Este proyecto es un sistema web responsive para la liga distrital San Pedro de Chorrillos.